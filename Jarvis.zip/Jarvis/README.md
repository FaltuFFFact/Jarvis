# Jarvis — Android voice assistant

"Jarvis" bolo, phir kaam bolo. Jawab ke baad kuch second tak bina "Jarvis" bole agli baat bhi sunta hai, phir apne aap so jata hai ("Jarvis, so jao" bolke turant sulaa sakte ho).

## Kya kar sakta hai
- Call lagana / kaatna / uthana, speaker on-off, SMS, WhatsApp message (Screen Control on ho to apne aap send)
- App kholna, alarm, timer, torch, Google search
- "YouTube par X chalao" — seedha video chalata hai
- Screen Control (Accessibility) se doosre apps mein tap / type / scroll
- Memory: aapki baatein, aadatein, rishtedaar yaad rakhta hai (app mein dekh/mita sakte ho)
- Reminders: samay par notification + bolkar yaad dilata hai, phone restart ke baad bhi bache rehte hain

## Setup (ek baar)
1. APK install karo, app kholo.
2. API key daalo -> "1. API key save karo".
3. "2. Permissions do".
4. "3. Display over other apps" allow karo.
   **Agar toggle on nahi ho raha** (sideload ki hui app ke saath Android 13+ par aam hai): "3b" button dabao,
   khulne wale page mein upar-right teen bindu (⋮) -> **Allow restricted settings**. Phir 3 aur 5 dobara karo.
5. "4. Battery optimisation hatao".
6. "5. Screen Control on karo" -> list mein "Jarvis Screen Control" on karo.
7. Settings mein naam, "sir/boss", zaroori baatein, awaaz chuno -> SAVE.
8. **JARVIS START**.

## Sach-sach seemayein
- Phone power-off ho to kuch nahi chalega. Screen off/lock par chalega.
- Restart ke baad "Jarvis" sunne ke liye app kholkar ek baar START dabana padta hai (reminders apne aap wapas lag jate hain).
- "Soya hua" mode mein bhi mic sunta rehta hai, taaki "Jarvis" shabd pakad sake. Wo baatein na AI ko jati hain, na save hoti hain.
  Sach mein mic band rakhke wake word pakadna offline engine (jaise Picovoice Porcupine) se hi hota hai.
- Call ke dauran kuch phones mic band kar dete hain, to "speaker on" beech call mein na sune.
- Memory ki baatein phone mein rehti hain, par har command ke saath AI ko bheji jati hain.
- Awaaz Google TTS ki British male awaaz hai (film wale Jarvis jaisi nahi, uski nakal nahi ho sakti).
- Har command par API ka chhota kharcha lagta hai.

## Code
| File | Kaam |
|---|---|
| `JarvisService.kt` | Hamesha-chalu service: sunna, wake word, so/jaag, bolna |
| `Brain.kt` | AI se baat, personality + memory prompt, tools |
| `Actions.kt` | Phone ke asli kaam + tool list |
| `JarvisAccessibility.kt` | Screen par tap / type / scroll |
| `Memory.kt`, `Reminders.kt` | Yaaddasht aur reminders |
| `Voices.kt` | Awaaz chunna |
| `MainActivity.kt`, `SettingsActivity.kt`, `MemoryActivity.kt` | Screens |
