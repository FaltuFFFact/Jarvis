package com.pravesh.jarvis

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Reminders ko AlarmManager se schedule karta hai (setAlarmClock: exact alarm permission nahi chahiye). */
object Reminders {

    private fun operation(ctx: Context, r: Memory.Reminder): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java)
            .putExtra("id", r.id)
            .putExtra("text", r.text)
        return PendingIntent.getBroadcast(
            ctx, r.id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    fun schedule(ctx: Context, r: Memory.Reminder) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(r.timeMs, show), operation(ctx, r))
    }

    fun cancel(ctx: Context, r: Memory.Reminder) {
        ctx.getSystemService(AlarmManager::class.java).cancel(operation(ctx, r))
    }

    fun rescheduleAll(ctx: Context) {
        val now = System.currentTimeMillis()
        Memory(ctx).reminders().filter { it.timeMs > now }.forEach { schedule(ctx, it) }
    }
}

/** Reminder ka samay aane par chalta hai: notification + (service chalu ho to) bolkar yaad dilata hai. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("id", 0)
        val text = intent.getStringExtra("text").orEmpty()
        Memory(ctx).removeReminder(id)

        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("jarvis_reminder", "Jarvis Reminders", NotificationManager.IMPORTANCE_HIGH)
        )
        val n = Notification.Builder(ctx, "jarvis_reminder")
            .setContentTitle("Jarvis Reminder")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)

        val sp = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        val title = sp.getString("title", "sir").orEmpty().ifBlank { "sir" }
        val english = sp.getString("reply_lang", "english") == "english"
        val line = if (english) "Pardon the interruption, $title. A reminder: $text"
        else "$title, yaad dilana tha: $text"
        JarvisService.instance?.speakAnnouncement(line)
    }
}

/** Phone restart ke baad reminders dobara schedule karta hai. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) Reminders.rescheduleAll(ctx)
    }
}
