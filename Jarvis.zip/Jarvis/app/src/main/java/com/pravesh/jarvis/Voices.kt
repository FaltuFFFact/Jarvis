package com.pravesh.jarvis

import android.content.SharedPreferences
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/** Awaaz chunne ka kaam. Default: British male awaaz (Jarvis jaisi), halki bhaari pitch ke saath. */
object Voices {

    private val britishMale = listOf("en-gb-x-rjs", "en-gb-x-gbd", "en-gb-x-gbb")

    fun isEnglish(sp: SharedPreferences) = sp.getString("reply_lang", "english") == "english"

    private fun installed(tts: TextToSpeech): List<Voice> =
        (tts.voices ?: emptySet()).filter { !it.features.contains("notInstalled") }

    /** Settings mein dikhane ke liye us bhasha ki saari awaazein. */
    fun list(tts: TextToSpeech, english: Boolean): List<Voice> {
        val lang = if (english) "en" else "hi"
        return installed(tts).filter { it.locale.language == lang }.sortedBy { it.name }
    }

    fun apply(tts: TextToSpeech, sp: SharedPreferences) {
        val english = isEnglish(sp)
        val saved = sp.getString(if (english) "voice_en" else "voice_hi", "").orEmpty()
        val all = installed(tts)

        var v: Voice? = all.firstOrNull { it.name == saved }
        if (v == null && english) {
            v = britishMale.firstNotNullOfOrNull { p -> all.firstOrNull { it.name.startsWith(p) } }
                ?: all.firstOrNull { it.locale.language == "en" && it.locale.country == "GB" }
                ?: all.firstOrNull { it.locale.language == "en" }
        } else if (v == null) {
            v = all.firstOrNull { it.locale.language == "hi" }
        }

        if (v != null) tts.voice = v
        else tts.language = if (english) Locale.UK else Locale("hi", "IN")

        tts.setPitch(sp.getFloat("pitch", 0.85f))
        tts.setSpeechRate(0.95f)
    }
}
