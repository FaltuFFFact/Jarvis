package com.pravesh.jarvis

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Phone par asli kaam yahan hote hain. Har function Claude ko ek chhota result string lautata hai. */
class Actions(private val ctx: Context) {

    private val noAcc =
        "Screen Control (Accessibility) chalu nahi hai. Jarvis app mein 'Screen Control on karo' button se on karo."

    private var notified = false

    fun execute(name: String, a: JSONObject): String {
        notified = false
        val r = dispatch(name, a)
        return if (notified) {
            "$r NOTE: 'Display over other apps' permission is off, so the app could not open by itself. " +
                "A notification was posted; the user must tap it to open."
        } else r
    }

    private fun dispatch(name: String, a: JSONObject): String = when (name) {
        "call_contact" -> call(a.getString("target"))
        "end_call" -> endCall()
        "answer_call" -> answerCall()
        "speaker" -> speaker(a.getBoolean("on"))
        "send_sms" -> sendSms(a.getString("to"), a.getString("message"))
        "whatsapp_message" -> whatsapp(a.getString("to"), a.getString("message"))
        "open_app" -> openApp(a.getString("name"))
        "set_alarm" -> setAlarm(a.getInt("hour"), a.getInt("minute"), a.optString("label", "Jarvis"))
        "set_timer" -> setTimer(a.getInt("seconds"))
        "flashlight" -> flashlight(a.getBoolean("on"))
        "open_url" -> openUrl(a.getString("url"))
        "web_search" -> openUrl("https://www.google.com/search?q=" + Uri.encode(a.getString("query")))
        "youtube_play" -> youtubePlay(a.getString("query"))
        "screen_click" -> {
            val t = a.getString("text")
            withAcc { if (it.clickText(t)) "'$t' dabaya." else "'$t' screen par nahi mila." }
        }
        "screen_type" -> {
            val t = a.getString("text")
            val submit = a.optBoolean("submit", false)
            withAcc { if (it.typeText(t, submit)) "Likh diya." else "Koi text box nahi mila." }
        }
        "press_button" -> {
            val b = a.getString("button")
            withAcc { if (it.press(b)) "Ho gaya." else "Ye button nahi dab paya." }
        }
        "scroll_screen" -> {
            val down = a.getString("direction").lowercase() != "up"
            withAcc { if (it.scroll(down)) "Scroll kar diya." else "Scroll nahi ho paya." }
        }
        "wait" -> {
            Thread.sleep(a.optInt("seconds", 2).coerceIn(1, 8) * 1000L)
            "Ruk gaya."
        }
        "remember" -> if (Memory(ctx).add(a.getString("fact"))) "Yaad kar liya." else "Ye pehle se yaad hai."
        "forget" -> {
            val n = Memory(ctx).forget(a.getString("keyword"))
            if (n > 0) "$n baat bhula di." else "Aisi koi baat yaad nahi thi."
        }
        "set_reminder" -> setReminder(a.getString("text"), a.getString("datetime"))
        "list_reminders" -> listReminders()
        "cancel_reminder" -> cancelReminder(a.getString("keyword"))
        else -> "Ye tool maujood nahi hai: $name"
    }

    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private inline fun withAcc(block: (JarvisAccessibility) -> String): String {
        val svc = JarvisAccessibility.instance ?: return noAcc
        return block(svc)
    }

    /**
     * Background se activity kholne ke liye Android "Display over other apps" maangta hai.
     * Wo na ho to chup-chaap fail hone ki jagah ek notification dikhate hain jise tap karke user khol sakta hai.
     */
    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Settings.canDrawOverlays(ctx)) {
            ctx.startActivity(i)
            return
        }
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("jarvis_open", "Jarvis open", NotificationManager.IMPORTANCE_HIGH)
        )
        val pi = PendingIntent.getActivity(
            ctx, (System.currentTimeMillis() % 100000).toInt(), i,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, "jarvis_open")
            .setContentTitle("Jarvis: kholne ke liye tap karo")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(777, n)
        notified = true
    }

    // ---------- Contacts ----------

    private fun resolveNumber(target: String): String? {
        val onlyNumber = target.none { it.isLetter() } && target.count { it.isDigit() } >= 5
        if (onlyNumber) return target.filter { it.isDigit() || it == '+' }
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val cols = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER)
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, cols,
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$target%"), null
        )?.use { c -> if (c.moveToFirst()) return c.getString(0) }
        return null
    }

    // ---------- Calls ----------

    private fun call(target: String): String {
        if (!has(Manifest.permission.CALL_PHONE)) return "CALL_PHONE permission nahi mili."
        val number = resolveNumber(target) ?: return "Contact '$target' nahi mila."
        val uri = Uri.fromParts("tel", number, null)
        return try {
            ctx.getSystemService(TelecomManager::class.java).placeCall(uri, Bundle())
            "Call laga raha hoon: $target"
        } catch (e: Exception) {
            try {
                launch(Intent(Intent.ACTION_CALL, uri))
                "Call laga raha hoon: $target"
            } catch (e2: Exception) {
                "Call nahi laga paya: ${e2.message}"
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun endCall(): String {
        if (Build.VERSION.SDK_INT < 28) return "Is Android version par call kaatna supported nahi hai."
        if (!has(Manifest.permission.ANSWER_PHONE_CALLS)) return "ANSWER_PHONE_CALLS permission nahi mili."
        val ok = ctx.getSystemService(TelecomManager::class.java).endCall()
        return if (ok) "Call kaat diya." else "Koi chalu call nahi mili ya kaat nahi paya."
    }

    private fun answerCall(): String {
        if (!has(Manifest.permission.ANSWER_PHONE_CALLS)) return "ANSWER_PHONE_CALLS permission nahi mili."
        return try {
            ctx.getSystemService(TelecomManager::class.java).acceptRingingCall()
            "Call utha li."
        } catch (e: Exception) {
            "Call utha nahi paya."
        }
    }

    @Suppress("DEPRECATION")
    private fun speaker(on: Boolean): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        if (Build.VERSION.SDK_INT >= 31) {
            if (on) {
                val d = am.availableCommunicationDevices
                    .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                    ?: return "Speaker device nahi mila."
                return if (am.setCommunicationDevice(d)) "Speaker on kar diya." else "Speaker on nahi ho paya."
            }
            am.clearCommunicationDevice()
            return "Speaker band kar diya."
        }
        am.isSpeakerphoneOn = on
        return if (on) "Speaker on kar diya." else "Speaker band kar diya."
    }

    // ---------- Messages ----------

    private fun sendSms(to: String, message: String): String {
        if (!has(Manifest.permission.SEND_SMS)) return "SEND_SMS permission nahi mili."
        val number = resolveNumber(to) ?: return "Contact '$to' nahi mila."
        val sms = if (Build.VERSION.SDK_INT >= 31) {
            ctx.getSystemService(SmsManager::class.java)
        } else {
            @Suppress("DEPRECATION") SmsManager.getDefault()
        }
        sms.sendMultipartTextMessage(number, null, sms.divideMessage(message), null, null)
        return "SMS bhej diya: $to"
    }

    private fun whatsapp(to: String, message: String): String {
        val number = resolveNumber(to) ?: return "Contact '$to' nahi mila."
        var digits = number.filter { it.isDigit() }
        if (digits.length == 10) digits = "91$digits"
        val uri = Uri.parse("https://wa.me/$digits?text=" + Uri.encode(message))
        try {
            launch(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: Exception) {
            return "WhatsApp nahi khul paya: ${e.message}"
        }
        val auto = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getBoolean("wa_autosend", true)
        val svc = JarvisAccessibility.instance
        if (!auto || svc == null) {
            return "WhatsApp mein message likh diya hai, lekin send button user ko dabana hoga " +
                "(Screen Control on ho to main khud bhej dunga)."
        }
        repeat(12) {
            Thread.sleep(800)
            if (svc.clickExact("send")) return "WhatsApp par message bhej diya."
        }
        return "Message likha hua hai, par send button nahi mila. User ko khud dabana hoga."
    }

    // ---------- Apps & system ----------

    private fun openApp(name: String): String {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val q = name.lowercase().replace(" ", "")
        val apps = pm.queryIntentActivities(main, 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().replace(" ", "").contains(q) }
            ?: apps.firstOrNull { it.activityInfo.packageName.lowercase().contains(q) }
            ?: return "App '$name' nahi mila. Naam English mein try karo."
        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "App '$name' khul nahi sakta."
        launch(i)
        return "$name khol diya."
    }

    /** YouTube ke search page se pehle video ki ID nikalta hai (Screen Control ke bina bhi kaam karta hai). */
    private fun firstYoutubeId(query: String): String? {
        val c = URL("https://www.youtube.com/results?search_query=" + Uri.encode(query))
            .openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty(
            "User-Agent",
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
        )
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        c.setRequestProperty("Cookie", "CONSENT=YES+1")
        val html = c.inputStream.bufferedReader().use { it.readText() }
        val m = Regex("\"videoRenderer\":\\{\"videoId\":\"([A-Za-z0-9_-]{11})\"").find(html)
            ?: Regex("\"videoId\":\"([A-Za-z0-9_-]{11})\"").find(html)
        return m?.groupValues?.get(1)
    }

    private fun youtubePlay(query: String): String {
        val id = try { firstYoutubeId(query) } catch (e: Exception) { null }
        if (id != null) {
            val u = Uri.parse("https://www.youtube.com/watch?v=$id")
            try {
                launch(Intent(Intent.ACTION_VIEW, u).setPackage("com.google.android.youtube"))
            } catch (e: ActivityNotFoundException) {
                launch(Intent(Intent.ACTION_VIEW, u))
            }
            return "YouTube par '$query' chala diya."
        }
        val url = "https://www.youtube.com/results?search_query=" + Uri.encode(query)
        try {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.google.android.youtube"))
        } catch (e: ActivityNotFoundException) {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
        val svc = JarvisAccessibility.instance
            ?: return "YouTube par '$query' ki search khol di hai. Video apne aap chalane ke liye Screen Control on karna hoga."
        Thread.sleep(3500)
        repeat(10) {
            if (svc.clickFirstYoutubeResult()) return "YouTube par '$query' chala diya."
            Thread.sleep(700)
        }
        return "YouTube par '$query' ki search khul gayi hai, par pehla video apne aap nahi dab paya."
    }

    private fun setAlarm(hour: Int, minute: Int, label: String): String {
        launch(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return "Alarm laga diya: %02d:%02d".format(hour, minute)
    }

    private fun setTimer(seconds: Int): String {
        launch(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return "Timer laga diya: $seconds second."
    }

    private fun flashlight(on: Boolean): String {
        val cm = ctx.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Flashlight nahi mili."
        cm.setTorchMode(id, on)
        return if (on) "Flashlight on." else "Flashlight off."
    }

    private fun openUrl(url: String): String {
        launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        return "Khol diya."
    }

    // ---------- Reminders ----------

    private val timeFmt get() = SimpleDateFormat("d MMM, hh:mm a", Locale.ENGLISH)

    private fun setReminder(text: String, datetime: String): String {
        val parsed = try {
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ENGLISH).parse(datetime.trim())?.time
        } catch (e: Exception) {
            null
        }
        if (parsed == null) return "Samay samajh nahi aaya. Format hona chahiye: yyyy-MM-dd HH:mm"
        if (parsed <= System.currentTimeMillis()) return "Ye samay beet chuka hai."
        val r = Memory(ctx).addReminder(parsed, text)
        Reminders.schedule(ctx, r)
        return "Reminder set: ${timeFmt.format(Date(parsed))} - $text"
    }

    private fun listReminders(): String {
        val list = Memory(ctx).reminders()
        if (list.isEmpty()) return "Koi reminder baaki nahi hai."
        return list.joinToString("; ") { "${timeFmt.format(Date(it.timeMs))}: ${it.text}" }
    }

    private fun cancelReminder(keyword: String): String {
        val mem = Memory(ctx)
        val hits = mem.reminders().filter { it.text.contains(keyword, ignoreCase = true) }
        if (hits.isEmpty()) return "Aisa koi reminder nahi mila."
        hits.forEach {
            Reminders.cancel(ctx, it)
            mem.removeReminder(it.id)
        }
        return "${hits.size} reminder hata diya."
    }
}

/** Claude ko batate hain ki kaun-kaun se tools maujood hain. */
object Tools {
    private data class P(val name: String, val type: String, val desc: String, val required: Boolean = true)

    private fun t(name: String, desc: String, vararg p: P): JSONObject {
        val props = JSONObject()
        val req = JSONArray()
        p.forEach {
            props.put(it.name, JSONObject().put("type", it.type).put("description", it.desc))
            if (it.required) req.put(it.name)
        }
        return JSONObject()
            .put("name", name)
            .put("description", desc)
            .put(
                "input_schema",
                JSONObject().put("type", "object").put("properties", props).put("required", req)
            )
    }

    /** Wahi tools, OpenAI/OpenRouter ke format mein. */
    fun openAiSchema(): JSONArray {
        val out = JSONArray()
        val s = schema()
        for (i in 0 until s.length()) {
            val t = s.getJSONObject(i)
            out.put(
                JSONObject().put("type", "function").put(
                    "function",
                    JSONObject()
                        .put("name", t.getString("name"))
                        .put("description", t.getString("description"))
                        .put("parameters", t.getJSONObject("input_schema"))
                )
            )
        }
        return out
    }

    fun schema(): JSONArray = JSONArray()
        .put(t("call_contact", "Kisi contact ya phone number ko call lagao.",
            P("target", "string", "Contact ka naam (jaise saved hai) ya phone number")))
        .put(t("end_call", "Chalu call kaat do."))
        .put(t("answer_call", "Aati hui call utha lo."))
        .put(t("speaker", "Call ka speaker on ya off karo.",
            P("on", "boolean", "true = speaker on, false = off")))
        .put(t("send_sms", "SMS bhejo.",
            P("to", "string", "Contact ka naam ya number"),
            P("message", "string", "Message ka text")))
        .put(t("whatsapp_message", "WhatsApp par message bhejo (Screen Control on ho to apne aap send bhi ho jata hai).",
            P("to", "string", "Contact ka naam ya number"),
            P("message", "string", "Message ka text")))
        .put(t("open_app", "Phone ka koi app kholo.",
            P("name", "string", "App ka naam English mein, jaise YouTube, Camera, Settings, WhatsApp")))
        .put(t("youtube_play", "YouTube par kuch search karke pehla video chala do. Gaana, video ya kuch bhi chalane ke liye use karo.",
            P("query", "string", "Jo video/gaana chalana hai uska naam")))
        .put(t("screen_click", "Screen par dikh rahe kisi button ya text ko tap karo (Screen Control chahiye).",
            P("text", "string", "Button ya text jo screen par likha hai")))
        .put(t("screen_type", "Jis text box mein cursor hai usme text likho (Screen Control chahiye).",
            P("text", "string", "Jo likhna hai"),
            P("submit", "boolean", "true to likhne ke baad Enter/Search dabao", false)))
        .put(t("press_button", "Phone ka system button dabao.",
            P("button", "string", "back, home, recents ya notifications")))
        .put(t("scroll_screen", "Screen ko scroll karo.",
            P("direction", "string", "down ya up")))
        .put(t("wait", "Kuch second ruko (jaise app khulne ke baad, agla step karne se pehle).",
            P("seconds", "integer", "1 se 8 second", false)))
        .put(t("set_alarm", "Alarm lagao.",
            P("hour", "integer", "Ghanta, 24-hour format (0-23)"),
            P("minute", "integer", "Minute (0-59)"),
            P("label", "string", "Alarm ka naam", false)))
        .put(t("set_timer", "Timer lagao.",
            P("seconds", "integer", "Timer ka total samay seconds mein")))
        .put(t("flashlight", "Torch on ya off karo.",
            P("on", "boolean", "true = on, false = off")))
        .put(t("open_url", "Browser mein link kholo.",
            P("url", "string", "Poora https link")))
        .put(t("web_search", "Google par kuch search karo.",
            P("query", "string", "Search query")))
        .put(t("remember", "User ki koi zaroori baat, aadat, pasand, rishtedaar ya routine yaad rakho. Ek chhoti line mein likho.",
            P("fact", "string", "Yaad rakhne wali baat, ek chhoti line")))
        .put(t("forget", "Yaad ki hui koi baat bhula do.",
            P("keyword", "string", "Us baat ka koi shabd")))
        .put(t("set_reminder", "User ko kisi samay par yaad dilane ke liye reminder lagao. Samay local time mein, yyyy-MM-dd HH:mm format mein.",
            P("text", "string", "Kis baat ki yaad dilani hai"),
            P("datetime", "string", "Samay, jaise 2026-11-12 07:30")))
        .put(t("list_reminders", "Baaki sab reminders batao."))
        .put(t("cancel_reminder", "Koi reminder hata do.",
            P("keyword", "string", "Reminder ke text ka koi shabd")))
}
