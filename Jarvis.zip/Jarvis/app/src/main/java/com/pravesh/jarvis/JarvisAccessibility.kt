package com.pravesh.jarvis

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Screen control: Jarvis ko screen par tap karne, type karne, scroll karne deta hai.
 * Iske liye user ko Settings > Accessibility mein ise ek baar on karna padta hai.
 */
class JarvisAccessibility : AccessibilityService() {

    companion object {
        @Volatile
        var instance: JarvisAccessibility? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---------- helpers ----------

    private fun walk(node: AccessibilityNodeInfo?, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (node == null) return null
        if (pred(node)) return node
        for (i in 0 until node.childCount) {
            val hit = walk(node.getChild(i), pred)
            if (hit != null) return hit
        }
        return null
    }

    private fun clickNode(node: AccessibilityNodeInfo?): Boolean {
        var cur = node
        var guard = 0
        while (cur != null && guard++ < 8) {
            if (cur.isClickable && cur.isEnabled) {
                return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            cur = cur.parent
        }
        return false
    }

    // ---------- actions ----------

    fun press(button: String): Boolean = when (button.lowercase()) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        else -> false
    }

    /** Jis element ke text ya description mein ye shabd ho, use dabao. */
    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val q = text.lowercase()
        val hit = walk(root) { n ->
            (n.text?.toString()?.lowercase()?.contains(q) == true) ||
                (n.contentDescription?.toString()?.lowercase()?.contains(q) == true)
        }
        return clickNode(hit)
    }

    /** Sirf poora match (jaise WhatsApp ka "Send" button). */
    fun clickExact(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val q = text.lowercase()
        val hit = walk(root) { n ->
            (n.text?.toString()?.lowercase() == q) ||
                (n.contentDescription?.toString()?.lowercase() == q)
        }
        return clickNode(hit)
    }

    /** Jis box mein cursor hai (ya pehla edit box) usme text likho. */
    fun typeText(text: String, submit: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: walk(root) { it.isEditable }
            ?: return false
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        val ok = field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok && submit && Build.VERSION.SDK_INT >= 30) {
            field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return ok
    }

    fun scroll(down: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = walk(root) { it.isScrollable } ?: return false
        val action = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return node.performAction(action)
    }

    /** YouTube search results mein pehla (Shorts ke alawa) video dabata hai. */
    fun clickFirstYoutubeResult(): Boolean {
        val root = rootInActiveWindow ?: return false
        val hit = walk(root) { n ->
            val d = n.contentDescription?.toString()?.lowercase().orEmpty()
            d.isNotEmpty() && !d.contains("shorts") &&
                (d.contains("play video") ||
                    (d.contains(" views") && d.contains(" ago") && (d.contains("minute") || d.contains("second"))))
        }
        return clickNode(hit)
    }
}
