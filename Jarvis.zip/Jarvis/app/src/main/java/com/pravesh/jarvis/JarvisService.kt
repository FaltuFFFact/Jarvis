package com.pravesh.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Hamesha background mein chalne wali service.
 *
 * Do halat hain:
 *  - SOYA HUA: sirf "Jarvis" shabd pakadta hai. Baaki jo bhi sunta hai use na API ko bhejta hai, na yaad rakhta hai.
 *  - JAAGA HUA: "Jarvis" bolte hi command leta hai, kaam karke jawab deta hai, phir kuch second (Settings mein tay)
 *    tak bina "Jarvis" bole agli baat bhi sunta hai. Phir apne aap wapas so jata hai.
 */
class JarvisService : Service() {

    companion object {
        @Volatile
        var instance: JarvisService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var overlay: View? = null
    private lateinit var brain: Brain

    @Volatile private var running = true
    private var speaking = false
    private var busy = false

    // Jaage hone ki khidki: jab tak ye samay nahi beetta, "Jarvis" bole bina bhi command chalti hai.
    private var activeUntil = 0L
    private var expectCommand = false   // "Ji, boliye" ke baad agli baat command hai
    private var endSession = false      // "so jao" ke baad khidki mat kholo

    private val sp get() = getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private val english get() = Voices.isEnglish(sp)
    private val title get() = sp.getString("title", "sir").orEmpty().ifBlank { "sir" }

    private val wakeWords = listOf(
        "jarvis", "jarvish", "jarwis", "jaarvis", "jarvice", "service jarvis",
        "जार्विस", "जारविस", "जर्विस", "जार्विश", "जारविश", "जरविस"
    )

    private val sleepPhrases = listOf(
        "so jao", "go to sleep", "that will be all", "that's all", "that is all", "bas itna hi",
        "सो जाओ", "बस इतना ही", "बस इतना"
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            startAsForeground()
        } catch (e: Exception) {
            stopSelf()
            return
        }
        instance = this
        addOverlayAnchor()
        brain = Brain(this)

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:listen").apply { acquire() }

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val t = tts ?: return@TextToSpeech
                Voices.apply(t, sp)
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) = finishedSpeaking(utteranceId)
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = finishedSpeaking(utteranceId)
                })
                ttsReady = true
                main.post {
                    speak(if (english) "J.A.R.V.I.S. online. At your service, $title."
                          else "जार्विस तैयार है, $title।")
                }
            }
        }

        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(listener)
            }
            listen()
        } else {
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        instance = null
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        overlay?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        tts?.stop()
        tts?.shutdown()
        worker.shutdownNow()
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    /** Reminder jaisi cheezein bolne ke liye (ReminderReceiver yahi bulata hai). */
    fun speakAnnouncement(text: String) {
        main.post { speak(text, "announce") }
    }

    // ---------- Sunna ----------

    private fun listen() {
        if (!running || speaking || busy) return
        val r = recognizer ?: return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try {
            r.cancel()
            r.startListening(i)
        } catch (e: Exception) {
            main.postDelayed({ listen() }, 1000)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull().orEmpty()
            handleHeard(text)
        }

        override fun onError(error: Int) {
            val delay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 300L
            main.postDelayed({ listen() }, delay)
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleHeard(text: String) {
        if (text.isBlank()) { listen(); return }

        val lower = text.lowercase(Locale.ROOT)
        val hit = wakeWords
            .map { lower.indexOf(it) to it.length }
            .filter { it.first >= 0 }
            .minByOrNull { it.first }
        val awake = System.currentTimeMillis() < activeUntil || expectCommand

        val command = when {
            hit != null -> text.substring(hit.first + hit.second).trim(' ', ',', '.', '!', '?', '-', '।')
            awake -> text.trim()
            else -> { listen(); return }   // soya hua: kuch nahi karna
        }
        expectCommand = false

        if (command.isBlank()) {
            expectCommand = true
            speak(if (english) "Yes, $title?" else "जी $title, बोलिए।")
            return
        }

        val c = command.lowercase(Locale.ROOT)
        if (sleepPhrases.any { c.contains(it) }) {
            activeUntil = 0L
            endSession = true
            speak(if (english) "Very well, $title. I'll be here." else "ठीक है $title।")
            return
        }
        runCommand(command)
    }

    // ---------- Kaam ----------

    private fun runCommand(cmd: String) {
        busy = true
        worker.execute {
            val reply = try {
                brain.ask(cmd)
            } catch (e: Exception) {
                friendlyError(e)
            }
            main.post {
                busy = false
                speak(reply)
            }
        }
    }

    // ---------- Bolna ----------

    private fun speak(text: String, utterance: String = "jarvis") {
        if (!ttsReady || text.isBlank()) { listen(); return }
        speaking = true
        recognizer?.cancel()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utterance)
    }

    private fun finishedSpeaking(utteranceId: String?) {
        main.post {
            speaking = false
            if (utteranceId == "jarvis" && !endSession) {
                val windowMs = if (expectCommand) 10_000L else sp.getInt("follow_sec", 15) * 1000L
                activeUntil = System.currentTimeMillis() + windowMs
            }
            endSession = false
            listen()
        }
    }

    private fun friendlyError(e: Exception): String {
        val m = e.message.orEmpty()
        val en = english
        return when {
            e is java.net.UnknownHostException || e is java.net.SocketTimeoutException ->
                if (en) "I can't reach the internet, $title." else "इंटरनेट नहीं चल रहा है।"
            m.contains("API error 401") ->
                if (en) "The API key seems to be wrong. Please paste it again in the app."
                else "API की गलत है। ऐप में दोबारा डालिए।"
            m.contains("API error 402") || m.contains("credit balance", ignoreCase = true) ->
                if (en) "The API account has run out of credits." else "API में क्रेडिट खत्म हैं।"
            m.contains("API error 404") ->
                if (en) "That model was not found. Check the Model box in Settings."
                else "मॉडल नहीं मिला। सेटिंग्स में मॉडल जाँचिए।"
            m.contains("API error 429") ->
                if (en) "Too many requests. Please try again shortly." else "बहुत ज़्यादा रिक्वेस्ट हैं, थोड़ी देर बाद कोशिश कीजिए।"
            else -> (if (en) "Something went wrong: " else "कुछ गड़बड़ हुई: ") + m.take(100)
        }
    }

    // ---------- Overlay ----------

    /**
     * 1x1 pixel ka invisible overlay. Isse Android is app ko "visible window wala" maanta hai,
     * aur background se bhi apps kholne deta hai. Iske liye "Display over other apps" allow honi chahiye.
     */
    private fun addOverlayAnchor() {
        if (!Settings.canDrawOverlays(this)) return
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val v = View(this)
            val lp = WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.START or Gravity.TOP
            wm.addView(v, lp)
            overlay = v
        } catch (_: Exception) {
        }
    }

    // ---------- Notification ----------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis sun raha hai")
            .setContentText("\"Jarvis\" bolkar command dijiye")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }
}
