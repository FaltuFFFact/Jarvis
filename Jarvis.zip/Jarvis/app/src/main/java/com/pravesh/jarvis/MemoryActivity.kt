package com.pravesh.jarvis

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Jarvis ne jo kuch yaad rakha hai aur jo reminders baaki hain, wo yahan dikhte hain. */
class MemoryActivity : Activity() {

    private lateinit var memory: Memory
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        memory = Memory(this)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "JARVIS KI YAADDASHT"
            textSize = 22f
        })
        root.addView(TextView(this).apply {
            text = "Jarvis aapki baatein khud bhi yaad karta hai. Yahan dekho, jodo ya mitao.\n" +
                "(Ye baatein phone mein hi rehti hain, par har command ke saath AI ko bheji jati hain.)"
            setPadding(0, pad / 2, 0, pad / 2)
        })

        val input = EditText(this).apply {
            hint = "Kuch yaad karwana hai? (jaise: Meri behen ka naam Riya hai)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        root.addView(input)

        root.addView(Button(this).apply {
            text = "Yaad karao"
            setOnClickListener {
                if (memory.add(input.text.toString())) input.setText("")
                render()
            }
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        root.addView(Button(this).apply {
            text = "Saari baatein mita do"
            setOnClickListener {
                AlertDialog.Builder(this@MemoryActivity)
                    .setMessage("Jarvis ki yaad ki hui saari baatein mit jayengi. Pakka?")
                    .setPositiveButton("Haan, mita do") { _, _ -> memory.clearFacts(); render() }
                    .setNegativeButton("Nahi", null)
                    .show()
            }
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)

        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private fun row(text: String, onDelete: () -> Unit): LinearLayout {
        val pad = (8 * resources.displayMetrics.density).toInt()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, pad, 0, pad)
        }
        row.addView(TextView(this).apply { this.text = text },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Button(this).apply {
            this.text = "X"
            setOnClickListener { onDelete() }
        })
        return row
    }

    private fun heading(t: String) = TextView(this).apply {
        text = "\n$t"
        textSize = 18f
    }

    private fun render() {
        list.removeAllViews()

        list.addView(heading("Baaki reminders"))
        val reminders = memory.reminders()
        val fmt = SimpleDateFormat("d MMM, hh:mm a", Locale.ENGLISH)
        if (reminders.isEmpty()) {
            list.addView(TextView(this).apply { text = "Koi reminder baaki nahi hai." })
        }
        for (r in reminders) {
            list.addView(row("${fmt.format(Date(r.timeMs))}\n${r.text}") {
                Reminders.cancel(this, r)
                memory.removeReminder(r.id)
                render()
            })
        }

        list.addView(heading("Jarvis ko ye yaad hai"))
        val facts = memory.facts().reversed()
        if (facts.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Abhi kuch yaad nahi hai. Jarvis se bolo: \"Jarvis, remember that ...\""
            })
        }
        for (f in facts) {
            list.addView(row(f) { memory.removeExact(f); render() })
        }
    }
}
