package com.pravesh.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Setup screen: API key, permissions, Screen Control, Settings, Memory, Start/Stop. */
class MainActivity : Activity() {

    private val permissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.ANSWER_PHONE_CALLS,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.POST_NOTIFICATIONS
    )

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "JARVIS"
            textSize = 30f
        })

        status = TextView(this).apply { setPadding(0, pad / 2, 0, pad / 2) }
        root.addView(status)

        val key = EditText(this).apply {
            hint = "API key (sk-ant-... ya sk-or-...)"
            setText(prefs.getString("api_key", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        root.addView(key)

        fun button(label: String, onClick: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                setOnClickListener { onClick() }
            }, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }

        button("1. API key save karo") {
            prefs.edit().putString("api_key", key.text.toString().trim()).apply()
            Toast.makeText(this, "Save ho gayi", Toast.LENGTH_SHORT).show()
        }

        button("2. Permissions do") {
            requestPermissions(permissions, 1)
        }

        button("3. 'Display over other apps' allow karo") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }

        button("3b. Upar wala ya Screen Control on nahi ho raha? Yahan dabao") {
            Toast.makeText(
                this,
                "Khulne wale page mein UPAR RIGHT ke teen bindu (⋮) dabao, phir " +
                    "\"Allow restricted settings\" dabao. Uske baad 3 aur 5 dobara try karo.",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        }

        button("4. Battery optimisation hatao") {
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        }

        button("5. Screen Control on karo (Accessibility)") {
            Toast.makeText(this, "List mein \"Jarvis Screen Control\" chuno aur on karo.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        button("Settings (naam, awaaz, memory ka tareeka...)") {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        button("Jarvis ki yaaddasht dekho (memory + reminders)") {
            startActivity(Intent(this, MemoryActivity::class.java))
        }

        button("JARVIS START") {
            prefs.edit().putString("api_key", key.text.toString().trim()).apply()
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Pehle Permissions do (mic zaroori hai)", Toast.LENGTH_LONG).show()
            } else if (key.text.isBlank()) {
                Toast.makeText(this, "Pehle API key daalo", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, JarvisService::class.java))
                Toast.makeText(this, "Jarvis chalu. Ab \"Jarvis\" bolo.", Toast.LENGTH_LONG).show()
            }
        }

        button("JARVIS STOP") {
            stopService(Intent(this, JarvisService::class.java))
            Toast.makeText(this, "Jarvis band", Toast.LENGTH_SHORT).show()
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        fun mark(ok: Boolean) = if (ok) "ON" else "OFF"
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        status.text = "Mic permission: ${mark(mic)}\n" +
            "Display over other apps: ${mark(Settings.canDrawOverlays(this))}\n" +
            "Screen Control: ${mark(JarvisAccessibility.instance != null)}\n" +
            "Jarvis: ${if (JarvisService.instance != null) "chalu" else "band"}"
    }
}
