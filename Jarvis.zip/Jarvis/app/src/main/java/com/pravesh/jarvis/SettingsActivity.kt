package com.pravesh.jarvis

import android.app.Activity
import android.content.SharedPreferences
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Jarvis ki settings: naam, zaroori baatein, awaaz, follow-up samay, model, WhatsApp auto-send. */
class SettingsActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private var previewTts: TextToSpeech? = null
    private lateinit var titleBox: EditText
    private lateinit var nameBox: EditText
    private lateinit var notesBox: EditText
    private lateinit var followBox: EditText
    private lateinit var modelBox: EditText

    private fun english() = Voices.isEnglish(prefs)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun label(t: String) {
            root.addView(TextView(this).apply { text = t; setPadding(0, pad, 0, 0) })
        }
        fun wide(b: Button) {
            root.addView(b, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }

        root.addView(TextView(this).apply { text = "SETTINGS"; textSize = 26f })

        label("Jarvis aapko kya bole? (jaise: sir, boss)")
        titleBox = EditText(this).apply {
            setText(prefs.getString("title", "sir"))
            inputType = InputType.TYPE_CLASS_TEXT
        }
        root.addView(titleBox)

        label("Aapka naam")
        nameBox = EditText(this).apply {
            setText(prefs.getString("user_name", ""))
            inputType = InputType.TYPE_CLASS_TEXT
        }
        root.addView(nameBox)

        label("Zaroori baatein jo Jarvis hamesha yaad rakhe (aadatein, routine, pasand...)")
        notesBox = EditText(this).apply {
            setText(prefs.getString("notes", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
            gravity = Gravity.TOP
        }
        root.addView(notesBox)

        label("Jawab ke baad kitne second tak bina \"Jarvis\" bole agli baat sune? (0 = har baar Jarvis bolna padega)")
        followBox = EditText(this).apply {
            setText(prefs.getInt("follow_sec", 15).toString())
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        root.addView(followBox)

        label("Model (khali chhodo to default chalega)")
        modelBox = EditText(this).apply {
            setText(prefs.getString("model", ""))
            inputType = InputType.TYPE_CLASS_TEXT
        }
        root.addView(modelBox)

        label("Awaaz aur bhasha")
        val langBtn = Button(this)
        fun refreshLang() {
            langBtn.text = if (english())
                "Jawab ki bhasha: English (British Jarvis) - badalne ke liye dabao"
            else
                "Jawab ki bhasha: Hindi - badalne ke liye dabao"
        }
        refreshLang()
        langBtn.setOnClickListener {
            prefs.edit().putString("reply_lang", if (english()) "hindi" else "english").apply()
            refreshLang()
            preview()
        }
        wide(langBtn)

        wide(Button(this).apply {
            text = "Awaaz badlo (dabate jao, sunkar chuno)"
            setOnClickListener { cycleVoice() }
        })
        wide(Button(this).apply {
            text = "Awaaz bhaari / patli karo"
            setOnClickListener { cyclePitch() }
        })

        val waBtn = Button(this)
        fun refreshWa() {
            waBtn.text = if (prefs.getBoolean("wa_autosend", true))
                "WhatsApp message apne aap send: ON (dabao to band)"
            else
                "WhatsApp message apne aap send: OFF (dabao to on)"
        }
        refreshWa()
        waBtn.setOnClickListener {
            prefs.edit().putBoolean("wa_autosend", !prefs.getBoolean("wa_autosend", true)).apply()
            refreshWa()
        }
        wide(waBtn)

        wide(Button(this).apply {
            text = "SAVE KARO"
            setOnClickListener {
                save()
                Toast.makeText(this@SettingsActivity, "Save ho gaya. Jarvis STOP karke START karo.", Toast.LENGTH_LONG).show()
            }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun save() {
        prefs.edit()
            .putString("title", titleBox.text.toString().trim().ifBlank { "sir" })
            .putString("user_name", nameBox.text.toString().trim())
            .putString("notes", notesBox.text.toString().trim())
            .putInt("follow_sec", followBox.text.toString().trim().toIntOrNull()?.coerceIn(0, 120) ?: 15)
            .putString("model", modelBox.text.toString().trim())
            .apply()
    }

    override fun onPause() {
        save()
        super.onPause()
    }

    override fun onDestroy() {
        previewTts?.shutdown()
        super.onDestroy()
    }

    // ---------- Awaaz preview ----------

    private fun toast(msg: String) = runOnUiThread {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun withTts(block: (TextToSpeech) -> Unit) {
        val existing = previewTts
        if (existing != null) { block(existing); return }
        previewTts = TextToSpeech(this) { status ->
            val t = previewTts
            if (status == TextToSpeech.SUCCESS && t != null) block(t)
            else toast("Text-to-speech chalu nahi hua")
        }
    }

    private fun sample() =
        if (english()) "Good day. J.A.R.V.I.S. online, and at your service."
        else "जी, मैं जार्विस हूँ। बोलिए, क्या काम है?"

    private fun preview() = withTts { t ->
        Voices.apply(t, prefs)
        t.speak(sample(), TextToSpeech.QUEUE_FLUSH, null, "preview")
    }

    private fun cycleVoice() = withTts { t ->
        val list = Voices.list(t, english())
        if (list.isEmpty()) { toast("Is bhasha ki koi awaaz install nahi hai"); return@withTts }
        val idxKey = if (english()) "voice_idx_en" else "voice_idx_hi"
        val i = (prefs.getInt(idxKey, -1) + 1) % list.size
        val v = list[i]
        prefs.edit()
            .putInt(idxKey, i)
            .putString(if (english()) "voice_en" else "voice_hi", v.name)
            .apply()
        Voices.apply(t, prefs)
        t.speak(sample(), TextToSpeech.QUEUE_FLUSH, null, "preview")
        toast("Awaaz ${i + 1}/${list.size}: ${v.name}\nPasand aaye to ruk jao, phir Jarvis STOP aur START karo.")
    }

    private fun cyclePitch() = withTts { t ->
        val steps = floatArrayOf(1.0f, 0.85f, 0.7f, 0.55f)
        val cur = prefs.getFloat("pitch", 0.85f)
        val idx = steps.indexOfFirst { it < cur - 0.01f }.let { if (it == -1) 0 else it }
        val p = steps[idx]
        prefs.edit().putFloat("pitch", p).apply()
        Voices.apply(t, prefs)
        t.speak(sample(), TextToSpeech.QUEUE_FLUSH, null, "preview")
        toast("Pitch: $p (chhota = bhaari awaaz)\nPasand aaye to Jarvis STOP aur START karo.")
    }
}
