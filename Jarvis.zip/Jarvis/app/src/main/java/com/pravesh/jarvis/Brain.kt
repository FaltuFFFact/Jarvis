package com.pravesh.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Claude (ya OpenRouter) se baat karta hai, memory use karta hai aur tools (phone actions) chalata hai. */
class Brain(private val ctx: Context) {

    private val actions = Actions(ctx)
    private val memory = Memory(ctx)
    private val history = JSONArray()
    private val oaHistory = JSONArray()
    private val prefs get() = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    companion object {
        // Tez jawab ke liye Haiku. Zyada smart chahiye to app ki Settings mein Model box mein badal sakte ho.
        const val MODEL = "claude-haiku-5-5"
        const val OPENROUTER_MODEL = "anthropic/claude-haiku-4.5"
    }

    fun ask(userText: String): String {
        val key = prefs.getString("api_key", "").orEmpty()
        if (key.isBlank()) return "Please add your API key in the Jarvis app first."
        return if (key.startsWith("sk-or-")) askOpenRouter(key, userText) else askAnthropic(key, userText)
    }

    // ---------- Anthropic ----------

    private fun askAnthropic(key: String, userText: String): String {
        trimHistory()
        val startLen = history.length()
        history.put(
            JSONObject().put("role", "user").put(
                "content", JSONArray().put(JSONObject().put("type", "text").put("text", userText))
            )
        )
        try {
            for (step in 0 until 8) {
                val resp = callAnthropic(key)
                val content = resp.getJSONArray("content")
                history.put(JSONObject().put("role", "assistant").put("content", content))

                val spoken = StringBuilder()
                val results = JSONArray()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    when (b.getString("type")) {
                        "text" -> spoken.append(b.getString("text"))
                        "tool_use" -> {
                            val out = runTool(b.getString("name"), b.getJSONObject("input"))
                            results.put(
                                JSONObject()
                                    .put("type", "tool_result")
                                    .put("tool_use_id", b.getString("id"))
                                    .put("content", out)
                            )
                        }
                    }
                }
                if (resp.optString("stop_reason") != "tool_use") return spoken.toString().trim()
                history.put(JSONObject().put("role", "user").put("content", results))
            }
            return "I could not complete that."
        } catch (e: Exception) {
            while (history.length() > startLen) history.remove(history.length() - 1)
            throw e
        }
    }

    private fun runTool(name: String, input: JSONObject): String = try {
        actions.execute(name, input)
    } catch (e: Exception) {
        "Error: ${e.message}"
    }

    private fun callAnthropic(key: String): JSONObject {
        val model = prefs.getString("model", "").orEmpty().ifBlank { MODEL }
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 700)
            .put("system", systemPrompt())
            .put("tools", Tools.schema())
            .put("messages", history)

        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.doOutput = true
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw RuntimeException("API error $code: $text")
        return JSONObject(text)
    }

    // ---------- OpenRouter (OpenAI-style API) ----------

    private fun askOpenRouter(key: String, userText: String): String {
        trimOa()
        val startLen = oaHistory.length()
        oaHistory.put(JSONObject().put("role", "user").put("content", userText))
        try {
            for (step in 0 until 8) {
                val resp = callOpenRouter(key)
                val msg = resp.getJSONArray("choices").getJSONObject(0).getJSONObject("message")
                oaHistory.put(msg)
                val calls = msg.optJSONArray("tool_calls")
                if (calls == null || calls.length() == 0) {
                    return if (msg.isNull("content")) "" else msg.getString("content").trim()
                }
                for (i in 0 until calls.length()) {
                    val c = calls.getJSONObject(i)
                    val fn = c.getJSONObject("function")
                    val out = try {
                        val args = fn.optString("arguments", "{}").ifBlank { "{}" }
                        actions.execute(fn.getString("name"), JSONObject(args))
                    } catch (e: Exception) {
                        "Error: ${e.message}"
                    }
                    oaHistory.put(
                        JSONObject()
                            .put("role", "tool")
                            .put("tool_call_id", c.getString("id"))
                            .put("content", out)
                    )
                }
            }
            return "I could not complete that."
        } catch (e: Exception) {
            while (oaHistory.length() > startLen) oaHistory.remove(oaHistory.length() - 1)
            throw e
        }
    }

    private fun callOpenRouter(key: String): JSONObject {
        val model = prefs.getString("model", "").orEmpty().ifBlank { OPENROUTER_MODEL }
        val messages = JSONArray().put(JSONObject().put("role", "system").put("content", systemPrompt()))
        for (i in 0 until oaHistory.length()) messages.put(oaHistory.get(i))
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 700)
            .put("tools", Tools.openAiSchema())
            .put("messages", messages)

        val c = URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.doOutput = true
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw RuntimeException("API error $code: $text")
        val json = JSONObject(text)
        if (!json.has("choices")) {
            throw RuntimeException("API error: " + json.optJSONObject("error")?.optString("message"))
        }
        return json
    }

    // ---------- History ----------

    private fun trimHistory() {
        var guard = 0
        while (history.length() > 24 && guard++ < 80) {
            history.remove(0)
            while (history.length() > 0) {
                val m = history.getJSONObject(0)
                val first = m.optJSONArray("content")?.optJSONObject(0)
                if (m.getString("role") == "user" && first?.optString("type") == "text") break
                history.remove(0)
            }
        }
    }

    private fun trimOa() {
        var guard = 0
        while (oaHistory.length() > 24 && guard++ < 80) {
            oaHistory.remove(0)
            while (oaHistory.length() > 0 &&
                oaHistory.getJSONObject(0).getString("role") != "user"
            ) oaHistory.remove(0)
        }
    }

    // ---------- Personality + memory ----------

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE, yyyy-MM-dd HH:mm", Locale.ENGLISH).format(Date())
        val title = prefs.getString("title", "sir").orEmpty().ifBlank { "sir" }
        val name = prefs.getString("user_name", "").orEmpty()
        val english = Voices.isEnglish(prefs)

        val notes = prefs.getString("notes", "").orEmpty()
        val facts = memory.facts().takeLast(120)
        val factsText = if (facts.isEmpty()) "(abhi kuch yaad nahi)" else facts.joinToString("\n") { "- $it" }
        val rem = memory.reminders()
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ENGLISH)
        val remText = if (rem.isEmpty()) "(koi nahi)" else rem.joinToString("\n") { "- ${fmt.format(Date(it.timeMs))}: ${it.text}" }

        val lang = if (english) {
            "Reply in elegant, concise English, like the film JARVIS."
        } else {
            "Reply in simple Hindi written in Devanagari script (not Roman letters), because the reply is spoken aloud."
        }

        return """
            You are JARVIS, the user's personal AI butler running on their Android phone. You are loyal, calm, courteous, a little dry-witted, and completely devoted to this one user.
            Address the user as "$title"${if (name.isNotBlank()) " (their name is $name)" else ""}.
            Current local date and time: $now (India, IST).
            $lang
            Your reply is spoken aloud: keep it to one or two short sentences. No emoji, no markdown, no lists.
            The user speaks Hindi, English or a mix; speech recognition can garble words, so infer the intent sensibly.

            HOW TO WORK
            - When the user asks for an action, do it straight away with tools. Do not ask for permission for routine things.
            - Chain tools for multi-step jobs. Example: "YouTube kholo aur X chalao" -> youtube_play. For other apps: open_app, wait, then screen_click / screen_type / scroll_screen / press_button.
            - After a tool, trust its result. If it failed, say so plainly and say what the user can do. Never claim success that the tool did not report.
            - If a contact is not found, retry once with another spelling (Hindi/English) before giving up.
            - Reminders: convert the user's wording ("kal subah 7 baje") into an exact local time and call set_reminder. Confirm the time back in a few words.

            MEMORY (your long-term memory of the user, stored on this phone)
            - Whenever the user tells you something lasting about themselves (habits, preferences, family, friends, work, routines, important dates, goals, names of contacts and how they relate), call remember with one short line, silently, without making a fuss.
            - Use these memories to anticipate needs and personalise answers. If something here is relevant to the request, use it naturally. Never invent memories.
            - If the user says to forget something, call forget.
            Important things the user wrote in Settings (always respect these):
            ${if (notes.isBlank()) "(none)" else notes}

            What you remember about the user:
            $factsText

            Pending reminders:
            $remText
        """.trimIndent()
    }
}
