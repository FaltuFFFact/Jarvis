package com.pravesh.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Jarvis ki yaaddasht: user ke baare mein baatein (facts) aur reminders.
 * Sirf phone mein SharedPreferences mein saved rehti hai.
 */
class Memory(ctx: Context) {

    data class Reminder(val id: Int, val timeMs: Long, val text: String)

    private val prefs = ctx.applicationContext.getSharedPreferences("jarvis_memory", Context.MODE_PRIVATE)

    companion object {
        private val LOCK = Any()
        private const val MAX_FACTS = 200
    }

    // ---------- Facts ----------

    fun facts(): List<String> = synchronized(LOCK) { readFacts() }

    private fun readFacts(): List<String> {
        val arr = try { JSONArray(prefs.getString("facts_v2", "[]")) } catch (e: Exception) { JSONArray() }
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val s = arr.optString(i)
            if (s.isNotBlank()) out.add(s)
        }
        return out
    }

    private fun writeFacts(list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        prefs.edit().putString("facts_v2", arr.toString()).apply()
    }

    /** Nayi baat yaad karo. Pehle se hai to false lautata hai. */
    fun add(fact: String): Boolean = synchronized(LOCK) {
        val t = fact.trim()
        if (t.isEmpty()) return false
        val list = readFacts().toMutableList()
        if (list.any { it.equals(t, ignoreCase = true) }) return false
        list.add(t)
        while (list.size > MAX_FACTS) list.removeAt(0)
        writeFacts(list)
        true
    }

    /** Jis baat mein ye shabd ho wo sab bhula do. Kitni bhulayi wo lautata hai. */
    fun forget(keyword: String): Int = synchronized(LOCK) {
        val k = keyword.trim()
        if (k.isEmpty()) return 0
        val list = readFacts()
        val keep = list.filter { !it.contains(k, ignoreCase = true) }
        writeFacts(keep)
        list.size - keep.size
    }

    /** Bilkul yahi baat hatao (memory screen ke X button ke liye). */
    fun removeExact(fact: String) = synchronized(LOCK) {
        writeFacts(readFacts().filter { it != fact })
    }

    fun clearFacts() = synchronized(LOCK) { writeFacts(emptyList()) }

    // ---------- Reminders ----------

    fun reminders(): List<Reminder> = synchronized(LOCK) { readReminders().sortedBy { it.timeMs } }

    private fun readReminders(): List<Reminder> {
        val arr = try { JSONArray(prefs.getString("reminders", "[]")) } catch (e: Exception) { JSONArray() }
        val out = ArrayList<Reminder>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Reminder(o.optInt("id"), o.optLong("time"), o.optString("text")))
        }
        return out
    }

    private fun writeReminders(list: List<Reminder>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("time", it.timeMs).put("text", it.text)) }
        prefs.edit().putString("reminders", arr.toString()).apply()
    }

    fun addReminder(timeMs: Long, text: String): Reminder = synchronized(LOCK) {
        val list = readReminders().toMutableList()
        var id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        while (list.any { it.id == id }) id++
        val r = Reminder(id, timeMs, text.trim())
        list.add(r)
        writeReminders(list)
        r
    }

    fun removeReminder(id: Int) = synchronized(LOCK) {
        writeReminders(readReminders().filter { it.id != id })
    }
}
